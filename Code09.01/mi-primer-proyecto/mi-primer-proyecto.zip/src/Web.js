import React from 'react';
function Web(){
  return (
    <div className="container">
     <h1>Bienvenido a nuestro primer proyecto en React</h1>
    </div>
  )

}
export default Web;