import React from 'react';

function Banner(){
    return (
        <section className="banner">
            <h1 className="titulo">Tenemos lo mejor para ti...</h1>
        </section>
    )
}
export default Banner;