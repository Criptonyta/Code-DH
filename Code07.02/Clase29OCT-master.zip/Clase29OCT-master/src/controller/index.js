const peliculas = require('./peliculas')
const countries = require('./countries')
module.exports = { peliculas ,countries }