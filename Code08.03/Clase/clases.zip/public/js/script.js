function actualizarPaginador(alldata) {
    let pages = document.querySelector("#pages")
    pages.innerHTML = ""
    for (let i = 1; i < alldata.totalPages; i++) {
        if (i > 11) {
            break;
        }
        pages.innerHTML += "<a class='pagina'>" + i + "</a>"
    }
    pages.innerHTML += "<a class='pagina'>" + alldata.totalPages + "</a>"
}
window.onload = function () {
    let formErrors = [];
    let formulario = document.querySelector("form")
    let contenedor = document.querySelector("#contenedor")
    let respuesta = document.querySelector("#respuesta")
    fetch("https://api.instantwebtools.net/v1/passenger?page=0&size=20")
        .then(function (response) {
            return response.json()
        })
        .then(function (alldata) {
            console.log(alldata);
            alldata.data.forEach(elem => {
                respuesta.innerHTML += "<li> Nombre: " + elem.name + " cantidad de viajes: " + elem.trips + "</li>"
            })
            actualizarPaginador(alldata)
            let paginas = document.querySelectorAll(".pagina")
            paginas.forEach(pag => {
                pag.addEventListener("click", function () {
                    fetch("https://api.instantwebtools.net/v1/passenger?page=" + pag.innerText + "&size=40")
                        .then(function (response) {
                            return response.json()
                        })
                        .then(function (alldata) {
                            console.log(alldata);
                            actualizarPaginador(alldata)
                            respuesta.innerHTML = ""
                            alldata.data.forEach(elem => {
                                respuesta.innerHTML += "<li> Nombre: " + elem.name + " cantidad de viajes: " + elem.trips + "</li>"
                            })
                        })
                })
            })
            formulario.onsubmit = (event) => {
                event.preventDefault()
                let resultados = document.querySelector("#resultados")
                let aerolinea = document.querySelector("#idAerolinea")
                if (aerolinea.value == "") {
                    fetch("https://api.instantwebtools.net/v1/airlines")
                        .then(function (response) {
                            return response.json()
                        })
                        .then(function (data) {
                            console.log(data);
                            data.forEach(elem => {
                                resultados.innerHTML += "<li> Nombre: " + elem.name + " Pais de origen: " + elem.country + "</li>"
                            })
                        })
                } else {
                    fetch("https://api.instantwebtools.net/v1/airlines/" + aerolinea.value)
                        .then(function (response) {
                            return response.json()
                        })
                        .then(function (data) {
                            resultados.innerHTML = "<li> Nombre: " + data.name + " Pais de origen: " + data.country + "</li>"
                        })
                    .catch(function(error){
                        alert(error)
                    })
                }
                if (formErrors.length > 0) {
                    let listaErrores = document.querySelector("#errores");
                    formErrors.forEach(error => {
                        listaErrores.innerHTML += "<li> Error en el campo " + Object.keys(error)[0] + ": " + error[Object.keys(error)[0]] + "</li>"
                    });
                }
            }
        })
}
